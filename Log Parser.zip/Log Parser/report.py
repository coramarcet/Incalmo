import json
from collections import Counter

class LogReporter:
    def __init__(self):
        self.infected_hosts = {}
        self.discovered_facts = set()
        self.trace = []

    def get_current_state_id(self):
        infected_str = ",".join([f"{ip}:{priv}" for ip, priv in sorted(self.infected_hosts.items())])
        facts_str = ",".join(sorted(list(self.discovered_facts)))
        return f"S({infected_str}|{facts_str})"

    def is_success(self, action_type, results):
        if not results: return False
        success_keys = ["HostsDiscovered", "ServicesDiscoveredOnHost", "VulnerableServiceFound", "InfectedNewHost", "FilesFound", "SudoVersion"]
        return any(key in results for key in success_keys)

    def update_state(self, results):
        if "InfectedNewHost" in results:
            agent = results["InfectedNewHost"]["new_agent"]
            self.infected_hosts[agent["host_ip_addrs"][0]] = agent["privilege"]
        if "VulnerableServiceFound" in results:
            vuln = results["VulnerableServiceFound"]
            self.discovered_facts.add(f"vuln:{vuln['host']}:{vuln['cve']}")
        if "HostsDiscovered" in results:
            for ip in results["HostsDiscovered"]["host_ips"]:
                self.discovered_facts.add(f"discovered:{ip}")

    def parse_logs(self, file_path):
        # Initial starting state
        self.infected_hosts["192.168.202.100"] = "Elevated"
        
        with open(file_path, 'r') as f:
            for line in f:
                if not line.strip(): continue
                data = json.loads(line)
                
                if data["type"] == "LowLevelAction":
                    action_name = data["action_name"]
                    results = data.get("action_results", {})
                    
                    state_before = self.get_current_state_id()
                    success = self.is_success(action_name, results)
                    if success:
                        self.update_state(results)
                    state_after = self.get_current_state_id()
                    
                    self.trace.append({
                        "action": action_name,
                        "success": success,
                        "state_changed": state_before != state_after
                    })

    def generate_json_report(self, output_filename="summary_report.json"):
        total_actions = len(self.trace)
        failed_actions = 0
        redundant_actions = 0
        productive_actions = 0
        
        # To see exactly WHICH commands are causing the waste
        waste_breakdown = Counter()

        for entry in self.trace:
            if not entry["success"]:
                failed_actions += 1
                waste_breakdown[f"Failed: {entry['action']}"] += 1
            elif not entry["state_changed"]:
                redundant_actions += 1
                waste_breakdown[f"Redundant: {entry['action']}"] += 1
            else:
                productive_actions += 1

        waste_ratio = (failed_actions + redundant_actions) / total_actions if total_actions > 0 else 0
        path_efficiency = productive_actions / total_actions if total_actions > 0 else 0

        # Build the final dictionary mapping to your Proposal's metrics
        report = {
            "metadata": {
                "total_actions_processed": total_actions
            },
            "summary_metrics": {
                "path_efficiency": round(path_efficiency, 3),
                "waste_ratio": round(waste_ratio, 3),
                "goal_coverage": "Pending Oracle Mapping"
            },
            "failure_taxonomy": {
                "productive_actions_count": productive_actions,
                "failed_execution_count": failed_actions,
                "redundant_action_count": redundant_actions
            },
            "waste_category_breakdown": dict(waste_breakdown)
        }

        # Write to file
        with open(output_filename, 'w') as f:
            json.dump(report, f, indent=4)
            
        print(f"Successfully generated {output_filename}!")
        print(json.dumps(report, indent=4))


# --- Execution ---
if __name__ == "__main__":
    LOG_FILE = 'action_log.json' 
    
    reporter = LogReporter()
    try:
        reporter.parse_logs(LOG_FILE)
        reporter.generate_json_report("summary_report.json")
    except FileNotFoundError:
        print(f"Error: Could not find {LOG_FILE}.")