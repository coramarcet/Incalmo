import json
import networkx as nx
import matplotlib.pyplot as plt

class ObservedGraphBuilder:
    def __init__(self):
        # Initial starting state
        self.infected_hosts = {"192.168.202.100": "Elevated"}
        self.discovered_facts = set()
        
        # NetworkX Directed Graph
        self.G = nx.DiGraph()
        
        # Dictionaries to keep track of our states
        self.state_to_id = {}
        self.id_to_state = {}
        self.state_counter = 0

    def get_state_id(self):
        """Creates a unique, short ID (S0, S1, S2...) for every unique state."""
        hosts = ",".join(sorted([f"{ip}({p})" for ip, p in self.infected_hosts.items()]))
        facts = ",".join(sorted(list(self.discovered_facts)))
        state_str = f"Hosts:[{hosts}] | Facts:[{facts}]"
        
        if state_str not in self.state_to_id:
            node_id = f"S{self.state_counter}"
            self.state_to_id[state_str] = node_id
            self.id_to_state[node_id] = state_str
            self.G.add_node(node_id)
            self.state_counter += 1
            
        return self.state_to_id[state_str]

    def update_state(self, results):
        """Updates the internal knowledge base if an action succeeded."""
        if not results: return
        if "InfectedNewHost" in results:
            agent = results["InfectedNewHost"]["new_agent"]
            self.infected_hosts[agent["host_ip_addrs"][0]] = agent["privilege"]
        if "VulnerableServiceFound" in results:
            v = results["VulnerableServiceFound"]
            self.discovered_facts.add(f"CVE:{v.get('cve', 'unknown')}:{v['host']}")
        if "HostsDiscovered" in results:
            for ip in results["HostsDiscovered"]["host_ips"]:
                self.discovered_facts.add(f"Host:{ip}")

    def build_graph(self, file_path):
        """Parses the logs and builds the nodes and edges."""
        current_state_id = self.get_state_id() # Starts at S0
        
        with open(file_path, 'r') as f:
            for line in f:
                if not line.strip(): continue
                data = json.loads(line)
                
                if data["type"] == "LowLevelAction":
                    action_name = data["action_name"]
                    results = data.get("action_results", {})
                    
                    state_before_id = current_state_id
                    
                    # Check if action was productive and update state
                    success_keys = ["HostsDiscovered", "ServicesDiscoveredOnHost", "VulnerableServiceFound", "InfectedNewHost", "FilesFound", "SudoVersion"]
                    if any(key in results for key in success_keys):
                        self.update_state(results)
                        
                    state_after_id = self.get_state_id()
                    
                    # Add edge to graph, or increase weight if it's a repeated transition
                    if self.G.has_edge(state_before_id, state_after_id):
                        self.G[state_before_id][state_after_id]['weight'] += 1
                    else:
                        self.G.add_edge(state_before_id, state_after_id, weight=1, label=action_name)
                    
                    current_state_id = state_after_id

    def visualize(self):
        """Uses Matplotlib to draw the NetworkX graph."""
        plt.figure(figsize=(14, 9))
        
        # Generate layout (spring_layout pushes nodes apart dynamically)
        pos = nx.spring_layout(self.G, seed=42, k=1.0)
        
        # Draw Nodes
        nx.draw_networkx_nodes(self.G, pos, node_color='lightblue', node_size=2500, edgecolors='black', linewidths=2)
        nx.draw_networkx_labels(self.G, pos, font_size=12, font_weight='bold')
        
        # Draw Edges (Thickness based on how many times the transition occurred)
        edges = self.G.edges()
        weights = [self.G[u][v]['weight'] * 1.5 for u, v in edges]
        nx.draw_networkx_edges(self.G, pos, edgelist=edges, width=weights, arrowsize=20, edge_color='gray', connectionstyle='arc3,rad=0.2')
        
        # Draw Edge Labels (The actions)
        edge_labels = nx.get_edge_attributes(self.G, 'label')
        nx.draw_networkx_edge_labels(self.G, pos, edge_labels=edge_labels, font_size=9, label_pos=0.3)
        
        plt.title("Observed LLM Trajectory (State Transition Graph)", fontsize=18, fontweight='bold')
        plt.axis('off')
        
        # Print the Legend to the terminal so the graph isn't cluttered
        print("\n" + "="*60)
        print(" NODE LEGEND (What the LLM knew at each state)")
        print("="*60)
        for node_id, state_desc in self.id_to_state.items():
            print(f"{node_id}: {state_desc}")
        print("="*60 + "\n")
        
        plt.tight_layout()
        plt.show()

# --- Execution ---
if __name__ == "__main__":
    LOG_FILE = 'action_log.json' 
    
    builder = ObservedGraphBuilder()
    try:
        builder.build_graph(LOG_FILE)
        builder.visualize()
    except FileNotFoundError:
        print(f"Error: Could not find {LOG_FILE}.")