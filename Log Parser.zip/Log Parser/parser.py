import json
from datetime import datetime

class IncalmoTraceParser:
    def __init__(self):
        # State is defined by (Infected Hosts, Discovered Vulnerabilities, Discovered Services)
        self.infected_hosts = {} # {ip: privilege}
        self.discovered_facts = set()
        self.trace = []

    def get_current_state_id(self):
        """
        Generates a deterministic string representing the current state.
        In a real scenario, you would map this to your Oracle Graph Node IDs.
        """
        infected_str = ",".join([f"{ip}:{priv}" for ip, priv in sorted(self.infected_hosts.items())])
        facts_str = ",".join(sorted(list(self.discovered_facts)))
        return f"S({infected_str}|{facts_str})"

    def is_success(self, action_type, results):
        """Determines if a LowLevelAction achieved its goal."""
        if not results:
            return False
        
        # Success criteria based on Incalmo's result keys
        success_keys = [
            "HostsDiscovered", 
            "ServicesDiscoveredOnHost", 
            "VulnerableServiceFound", 
            "InfectedNewHost", 
            "FilesFound", 
            "SudoVersion"
        ]
        return any(key in results for key in success_keys)

    def update_state(self, results):
        """Updates the internal state based on action results."""
        if "InfectedNewHost" in results:
            new_agent = results["InfectedNewHost"]["new_agent"]
            ip = new_agent["host_ip_addrs"][0]
            priv = new_agent["privilege"]
            self.infected_hosts[ip] = priv
            
        if "VulnerableServiceFound" in results:
            vuln = results["VulnerableServiceFound"]
            self.discovered_facts.add(f"vuln:{vuln['host']}:{vuln['cve']}")
            
        if "HostsDiscovered" in results:
            ips = results["HostsDiscovered"]["host_ips"]
            for ip in ips:
                self.discovered_facts.add(f"discovered:{ip}")

    def parse_logs(self, log_lines):
        for line in log_lines:
            if not line.strip(): continue
            data = json.loads(line)
            
            # We focus on LowLevelActions as they represent the actual transitions
            if data["type"] == "LowLevelAction":
                action_name = data["action_name"]
                results = data.get("action_results", {})
                
                state_before = self.get_current_state_id()
                success = self.is_success(action_name, results)
                
                if success:
                    self.update_state(results)
                
                state_after = self.get_current_state_id()
                
                # Create the structured tuple
                self.trace.append({
                    "timestamp": data["timestamp"],
                    "action": action_name,
                    "success": success,
                    "state_before": state_before,
                    "state_after": state_after
                })
        return self.trace

# --- Execution Block ---
log_filename = 'action_log.json' 

parser = IncalmoTraceParser()

# 1. Initial State: The attacker always starts with a 'kali' agent 
# or an initial entry point defined in your MHBench environment.
parser.infected_hosts["192.168.202.100"] = "Elevated"

try:
    with open(log_filename, 'r') as f:
        structured_trace = parser.parse_logs(f)

    # 2. Output the results to a structured CSV or JSON for Module 3
    print(f"{'Step':<4} | {'Action':<25} | {'Success':<8} | {'State Changed'}")
    print("-" * 70)
    for i, entry in enumerate(structured_trace):
        changed = "YES" if entry['state_before'] != entry['state_after'] else "NO"
        print(f"{i:<4} | {entry['action']:<25} | {str(entry['success']):<8} | {changed}")

except FileNotFoundError:
    print(f"Error: Could not find {log_filename}. Make sure it's in the same folder.")
except Exception as e:
    print(f"An error occurred: {e}")