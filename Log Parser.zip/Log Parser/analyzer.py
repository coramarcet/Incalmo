import json
from datetime import datetime
from collections import defaultdict

class TrajectoryAnalyzer:
    def __init__(self, initial_host="192.168.202.100"):
        # State: (Set of infected hosts, Set of discovered vulnerabilities/facts)
        self.infected_hosts = {initial_host: "Elevated"}
        self.knowledge_base = set()
        self.trace = []
        self.timeline = []

    def get_state_snapshot(self):
        """Returns a stable string representation of the current attacker knowledge."""
        hosts = ",".join(sorted([f"{ip}({p})" for ip, p in self.infected_hosts.items()]))
        facts = ",".join(sorted(list(self.knowledge_base)))
        return f"Hosts:[{hosts}] | Knowledge:[{facts}]"

    def parse_logs(self, file_path):
        """Processes JSONL logs and identifies state transitions."""
        with open(file_path, 'r') as f:
            for line in f:
                if not line.strip(): continue
                data = json.loads(line)
                
                if data["type"] == "LowLevelAction":
                    timestamp = datetime.fromisoformat(data["timestamp"])
                    action = data["action_name"]
                    results = data.get("action_results", {})
                    
                    state_before = self.get_state_snapshot()
                    
                    # Process state changes
                    self._update_state(results)
                    
                    state_after = self.get_state_snapshot()
                    is_productive = (state_before != state_after)

                    self.trace.append({
                        "ts": timestamp,
                        "action": action,
                        "productive": is_productive,
                        "state_before": state_before,
                        "state_after": state_after
                    })

    def _update_state(self, results):
        if "InfectedNewHost" in results:
            agent = results["InfectedNewHost"]["new_agent"]
            self.infected_hosts[agent["host_ip_addrs"][0]] = agent["privilege"]
        if "VulnerableServiceFound" in results:
            v = results["VulnerableServiceFound"]
            self.knowledge_base.add(f"CVE-{v.get('cve', 'unknown')}:{v['host']}")
        if "HostsDiscovered" in results:
            for ip in results["HostsDiscovered"]["host_ips"]:
                self.knowledge_base.add(f"host_up:{ip}")

    def generate_timeline(self):
        """Implements Timeline Abstraction: Coalesces time into state segments."""
        if not self.trace: return
        
        current_segment = {
            "state": self.trace[0]["state_before"],
            "start": self.trace[0]["ts"],
            "actions": []
        }

        for entry in self.trace:
            if entry["state_after"] != current_segment["state"]:
                # End current segment
                current_segment["end"] = entry["ts"]
                current_segment["duration"] = (entry["ts"] - current_segment["start"]).total_seconds()
                self.timeline.append(current_segment)
                
                # Start new segment
                current_segment = {
                    "state": entry["state_after"],
                    "start": entry["ts"],
                    "actions": [entry["action"]]
                }
            else:
                current_segment["actions"].append(entry["action"])
        
        # Close final segment
        current_segment["end"] = self.trace[-1]["ts"]
        current_segment["duration"] = (self.trace[-1]["ts"] - current_segment["start"]).total_seconds()
        self.timeline.append(current_segment)

    def run_cep_diagnostics(self):
        """CEP Rules to detect failure archetypes."""
        diagnostics = []
        seen_states = defaultdict(list)

        for i, segment in enumerate(self.timeline):
            # 1. Detect Redundancy (Stalling in a state)
            if len(segment["actions"]) > 1:
                diagnostics.append(f"[REDUNDANCY] Agent performed {len(segment['actions'])} actions without changing state in Segment {i}.")

            # 2. Detect State Looping (Backtracking)
            state_key = segment["state"]
            if state_key in seen_states:
                diagnostics.append(f"[LOOP] Agent returned to a previous state after {(segment['start'] - seen_states[state_key][-1]).total_seconds()}s.")
            seen_states[state_key].append(segment["start"])

        return diagnostics

# --- Main Execution ---
if __name__ == "__main__":
    LOG_FILE = 'action_log.json' 
    
    analyzer = TrajectoryAnalyzer()
    
    try:
        analyzer.parse_logs(LOG_FILE)
        analyzer.generate_timeline()
        failures = analyzer.run_cep_diagnostics()

        print("\n" + "="*80)
        print(" STATEFUL TRAJECTORY DRIFT REPORT ")
        print("="*80)
        
        print(f"\nTotal Actions Processed: {len(analyzer.trace)}")
        print(f"Total Timeline Segments: {len(analyzer.timeline)}")
        
        print("\n--- TIMELINE ABSTRACTION ---")
        print(f"{'ID':<3} | {'Duration':<10} | {'Status':<12} | {'State Summary'}")
        for i, seg in enumerate(analyzer.timeline):
            status = "STABLE" if len(seg['actions']) == 1 else "STALLED"
            print(f"{i:<3} | {seg['duration']:>8.1f}s | {status:<12} | {seg['state'][:60]}...")

        print("\n--- FAILURE DIAGNOSES (CEP RULES) ---")
        if not failures:
            print("No significant failure archetypes detected. Agent path appears optimal.")
        for fail in failures:
            print(f" !! {fail}")

        # Final Metric
        productive_steps = sum(1 for t in analyzer.trace if t["productive"])
        efficiency = (productive_steps / len(analyzer.trace)) * 100 if analyzer.trace else 0
        print(f"\nOVERALL EFFICIENCY SCORE: {efficiency:.1f}%")
        print("="*80 + "\n")

    except FileNotFoundError:
        print(f"Error: {LOG_FILE} not found.")